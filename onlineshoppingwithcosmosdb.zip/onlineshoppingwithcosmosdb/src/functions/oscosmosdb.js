const { app } = require("@azure/functions");
const { CosmosClient } = require("@azure/cosmos");
app.http("insertnewproduct", {
  methods: ["POST"],
  authLevel: "anonymous",
  handler: async (request, context) => {
    context.log(`Http function processed request for url "${request.url}"`);

    const newProduct = await request.json();

    const endpoint =
      "https://onlineshoppingwithcosmosdb.documents.azure.com:443/";
    const key =
      "acOFjr0IZXXFUh0HzVanDJFXOerNdV6mV6L2myb6TQP7EWVyIQBIhdKpRrPxbnpOqQkcKW1KgyiLACDbWt9Y9Q==";

    const client = new CosmosClient({ endpoint, key });

    const { database } = await client.databases.createIfNotExists({
      id: "onlineshoppingdb",
    });

    const { container } = await database.containers.createIfNotExists({
      id: "products",
    });

    await container.items.create(newProduct);

    return { body: `Record inserted successfully !` };
  },
});
app.http("getallproducts", {
  methods: ["GET"],
  authLevel: "anonymous",
  handler: async (request, context) => {
    context.log(`Http function processed request for url "${request.url}"`);

    const endpoint =
      "https://onlineshoppingwithcosmosdb.documents.azure.com:443/";
    const key =
      "acOFjr0IZXXFUh0HzVanDJFXOerNdV6mV6L2myb6TQP7EWVyIQBIhdKpRrPxbnpOqQkcKW1KgyiLACDbWt9Y9Q==";

    const client = new CosmosClient({ endpoint, key });

    const { database } = await client.databases.createIfNotExists({
      id: "onlineshoppingdb",
    });

    const { container } = await database.containers.createIfNotExists({
      id: "products",
    });

    // use upsert for edit/update
    // use container.item().delete() for deleting

    const { resources } = await container.items
      .query("SELECT * from c")
      .fetchAll();

    return { jsonBody: resources };
  },
});
