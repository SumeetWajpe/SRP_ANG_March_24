import { Component } from '@angular/core';

@Component({
  selector: 'app-twowaybind',
  templateUrl: './twowaybind.component.html',
  styleUrl: './twowaybind.component.css',
})
export class TwowaybindComponent {
  data: string = 'Sharp';
}
